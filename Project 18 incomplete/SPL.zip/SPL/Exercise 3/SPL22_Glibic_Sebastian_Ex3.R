################################################################################ 
#################### Statistical Programming Languages 2022 ####################
####################             Take-home Exam             ####################
####################                                        ####################
####################   	  Eva-Maria Maier, Lisa Steyer      ####################
################################################################################

#-------------------------------------------------------------------------------
# Surname: Glibic
# Name: Sebastian
# Student ID (Matrikelnummer): 615137
#-------------------------------------------------------------------------------

### Exercise 3 -----------------------------------------------------------------

#a)
#generates 1 random value for variable u1 with mean 10 and standard deviation of 1
u1 <- rnorm(100, mean = 10, sd = 1) 
#generates random value for variable u2 with mean 10 and standard deviation of 2
u2 <- rnorm(100, mean = 10, sd = 2)
#now we see the example values for u2, running it multiple times shows us the variables are random
head(u2)
#We define v as random exponential variable with rate parameter lambda 0.5
v <- rexp(100,0.5)
#again check the values
head(v)
#now we can define our functions determining x1 and x2
x1 <- 0.5*u1-3*v+10
x2 <- 4*u2
#using the sample function for x1 and x2
sample(x1,100)
sample(x2,100)
#Compute kernel density estimates using the density function
#The result is a table with min/max and quartiles for x and y values of our functions
density(x1)
density(x2)

#b) 
#computing the median
median(x1) #prints median for x1
median(x2) #prints median for x2
#create a function that provides the kernel density estimates for x1 and x2
#source_ https://stackoverflow.com/questions/2547402/how-to-find-the-statistical-mode
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
modex1 <- Mode(x1)
modex2 <- Mode(x2)
modex1
modex2

#c)
#create the plot and the related measures of scale of the x-axis
plot(density(x1), xlim = c(- 4, 80))
#create the polygon to colour the area underneath
polygon(density(x1), col = rgb(0, 120, 255, max = 255, alpha = 80, names = "blue"))
#create the polygon for x2 in the same plot
polygon(density(x2), col = rgb(200, 30, 200, max = 255, alpha = 80, names = "pink"))



