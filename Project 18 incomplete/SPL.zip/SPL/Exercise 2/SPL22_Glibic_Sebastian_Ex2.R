################################################################################ 
#################### Statistical Programming Languages 2022 ####################
####################             Take-home Exam             ####################
####################                                        ####################
####################   	  Eva-Maria Maier, Lisa Steyer      ####################
################################################################################

#-------------------------------------------------------------------------------
# Surname: Glibic
# Name: Sebastian
# Student ID (Matrikelnummer): 615137
#-------------------------------------------------------------------------------

### Exercise 2 -----------------------------------------------------------------
#a)
getwd()
corona <- read.csv("corona.csv",TRUE,",")
class(corona)
head(corona)
corona2 <- corona[,-which(names(corona)%in%c("day","month","year","geoId","countryterritoryCode","continentExp"))]
head(corona2)
names(corona2)[names(corona2)=="dateRep"]<- "date"
names(corona2)[names(corona2)=="countriesAndTerritories"]<- "country"
names(corona2)[names(corona2)=="popData2020"]<- "population"
head(corona2)
lapply(corona2, class) 
#Lists the class types of the column entries. Since cases,deaths and population are real numbers, integer is assigned appropriate
#Date is changed to POSIXct
#country assigned as factor is possible since the categorical properties of the class factor match with the limited amount of countries
corona2$date <- as.POSIXct(corona2$date,format = "%d/%m/%Y");  #change the entries for date to POSIXt
lapply(corona2, class)
#b)
summary(corona2)#provides an overview, including the amount of Na entries per column
#c)
highcases <- nrow(corona2[corona2$cases>300, ]) #amount of rows/entries where cases are >300
highcases
totalcases <- nrow(corona2[corona2$cases>-1, ]) #total amount of rows/entries
totalcases
fraction <- highcases/totalcases #fraction defines the share of case entries that are >300 from total case entries that are not negative
paste(round(100*fraction, 2), "%", sep="")
#The share of case entries >300 is 62.24% from total non negative entries
#d)
t.test(corona2$indicator14[corona2$country=="Italy"], corona2$indicator14[corona2$country=="Spain"])
#Performs a Welch two sample t-test with significance level of 5%.
#The result shows a p-value of 0.4617,hence we reject the null-hypothesis and the mean indicator14 is statistically different in Italy and Spain
#e)
#first we create a new data frame called totaldeaths
totaldeathsoct <- data.frame(countries=(corona2$country),totaldeaths=(corona2$deaths))
#using the function aggregate and assigning the aggregated deaths to each country
aggregate(.~countries,data=totaldeathsoct,FUN=sum) #SUM ONLY FOR OCTOBER 2021

