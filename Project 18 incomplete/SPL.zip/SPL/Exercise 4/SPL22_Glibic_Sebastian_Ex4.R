################################################################################ 
#################### Statistical Programming Languages 2022 ####################
####################             Take-home Exam             ####################
####################                                        ####################
####################   	  Eva-Maria Maier, Lisa Steyer      ####################
################################################################################

#-------------------------------------------------------------------------------
# Surname: Glibic
# Name: Sebastian
# Student ID (Matrikelnummer): 615137
#-------------------------------------------------------------------------------

### Exercise 4 -----------------------------------------------------------------

#a)
polycoefs <- function(poly) {
  expr <- parse(text = poly)
  result <- numeric()
  env <- list2env(list(x = 0), parent = baseenv())
  i <- 0
  while (!identical(expr, 0)) {
    coef <- eval(expr, envir = env)/factorial(i)
    names(coef) <- paste0("x^", i)
    result <- c(result, coef)
    expr <- D(expr, "x")
    i <- i + 1
  }
  result
}
polycoefs("2*x^5 + x + 3*x^5 - 1 + 4*x")
#> x^0 x^1 x^2 x^3 x^4 x^5 
#>  -1   5   0   0   0   5
